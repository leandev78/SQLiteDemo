package com.miempresa.tiendaonline.tiendaonline.model;

import java.sql.Time;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;


@Entity
@Table(name="factura")
public class Factura {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //  Para H2 y MySQL funciona bien
    @Column(name="id_factura")
    private Long id_factura;

    @Column(name="id_cliente")
    private Long id_cliente;

    @Column(name="fecha")
    private LocalDateTime fecha;
    
    @Column(name="total")
    private Double total;


    @OneToMany(mappedBy = "factura", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<DetalleFactura> detalles = new ArrayList<>();



    public Factura() { }



    public Long getIdFactura() {  return id_factura; }
    public void setIdFactura(Long id_factura) {  this.id_factura = id_factura; }

    public Long getIdCliente() { return id_cliente; }
    public void setIdCliente(Long id_cliente) { this.id_cliente = id_cliente; }

    public LocalDateTime getFecha() { return fecha; }
    public void setFecha(LocalDateTime fecha) { this.fecha = fecha; }

    public Double getTotal() { return total; }
    public void setTotal(Double total) { this.total = total; }

    public List<DetalleFactura> getDetalles() { return detalles; }
    public void setDetalles(List<DetalleFactura> detalles) { this.detalles = detalles;}

         
}
