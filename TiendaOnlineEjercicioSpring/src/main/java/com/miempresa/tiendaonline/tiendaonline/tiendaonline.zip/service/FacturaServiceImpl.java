package com.miempresa.tiendaonline.tiendaonline.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.miempresa.tiendaonline.tiendaonline.model.DetalleFactura;
import com.miempresa.tiendaonline.tiendaonline.model.DetalleFacturaId;
import com.miempresa.tiendaonline.tiendaonline.model.Factura;
import com.miempresa.tiendaonline.tiendaonline.repository.DetalleFacturaRepository;
import com.miempresa.tiendaonline.tiendaonline.repository.FacturaRepository;

import jakarta.transaction.Transactional;

@Service
public class FacturaServiceImpl implements FacturaService {

    @Autowired
    private FacturaRepository facturaRepository;

    @Autowired
    private DetalleFacturaRepository detalleFacturaRepository;



    @Override
    public List<Factura> listarFacturas() {
        return facturaRepository.findAll();
    }


    @Override
    @Transactional
    public Factura guardar(Factura factura) {
        // Guardamos primero la factura
        Factura facturaGuardada = facturaRepository.save(factura);

        // Guardamos los detalles con su ID compuesto
        List<DetalleFactura> detalles = factura.getDetalles();
        if (detalles != null) {
            for (DetalleFactura detalle : detalles) {
                System.out.println("PASO POR GUARDAR DETALLE FACTURA!");
                // Seteamos manualmente el ID compuesto
                DetalleFacturaId id = new DetalleFacturaId();
                id.setIdFactura(facturaGuardada.getIdFactura());
                id.setIdProducto(detalle.getId().getIdProducto()); // El producto ya debe existir

                detalle.setId(id);
                detalleFacturaRepository.save(detalle);
            }
        }

        return facturaGuardada;
    }


}
