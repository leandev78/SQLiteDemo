package com.miempresa.tiendaonline.tiendaonline.service;

import java.util.List;

import com.miempresa.tiendaonline.tiendaonline.model.Factura;

public interface FacturaService {
    
    List<Factura> listarFacturas();

    Factura guardar(Factura factura);
}
