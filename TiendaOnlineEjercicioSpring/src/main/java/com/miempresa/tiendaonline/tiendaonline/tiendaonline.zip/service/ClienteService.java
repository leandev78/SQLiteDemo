package com.miempresa.tiendaonline.tiendaonline.service;

import java.util.List;

import com.miempresa.tiendaonline.tiendaonline.model.Cliente;

public interface ClienteService {
    List<Cliente> listarClientes();
}
